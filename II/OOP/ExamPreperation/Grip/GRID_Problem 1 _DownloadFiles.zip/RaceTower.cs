namespace GRID
{
    using System;
    using System.Collections.Generic;

    public class RaceTower
    {
        public void SetTrackInfo(int lapsNumber, int trackLength)
        {
            //TODO: Add some logic here …
            throw new NotImplementedException();
        }

        public void RegisterDriver(List<string> commandArgs)
        {
            //TODO: Add some logic here …
            throw new NotImplementedException();
        }

        public void DriverBoxes(List<string> commandArgs)
        {
            //TODO: Add some logic here …
            throw new NotImplementedException();
        }

        public string CompleteLaps(List<string> commandArgs)
        {
            //TODO: Add some logic here …
            throw new NotImplementedException();
        }

        public string GetLeaderboard()
        {
            //TODO: Add some logic here …
            throw new NotImplementedException();
        }
    }
}