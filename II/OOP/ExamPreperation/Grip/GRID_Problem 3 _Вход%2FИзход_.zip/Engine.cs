using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public class Engine
    {
        private RaceTower raceTower;
        public Engine()
        {
            raceTower = new RaceTower();
        }

        public void Run()
        {
            int totalLaps = int.Parse(Console.ReadLine());
            int trackLength = int.Parse(Console.ReadLine());

            raceTower.SetTrackInfo(totalLaps, trackLength);

            string input = Console.ReadLine();
            while (raceTower.winner == null)
            {
                InterpretCommand(input);
                if (raceTower.winner == null)
                    input = Console.ReadLine();
            }

            Console.WriteLine($"{raceTower.winner.Name} wins the race for {raceTower.winner.TotalTime:f3} seconds.");
        }

        public void InterpretCommand(string command)
        {
            var commandArgs = command.Split().ToList();
            switch (commandArgs[0])
            {
                case "RegisterDriver":
                    raceTower.RegisterDriver(commandArgs.Skip(1).ToList());
                    break;
                case "Leaderboard":
                    Console.WriteLine(raceTower.GetLeaderboard());
                    break;
                case "CompleteLaps":
                    try
                    {
                        raceTower.CompleteLaps(commandArgs.Skip(1).ToList());
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case "Box":
                    raceTower.DriverBoxes(commandArgs.Skip(1).ToList());
                    break;
            }
        }
    }
}
