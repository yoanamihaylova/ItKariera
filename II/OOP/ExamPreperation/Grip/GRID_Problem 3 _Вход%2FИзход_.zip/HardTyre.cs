using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public class HardTyre : Tyre
    {
        public HardTyre(double hardness) : base("Hard", hardness)
        {
        }

        public override double Degradation
        {
            get
            {
                return base.Degradation;
            }

            set
            {
                base.Degradation = value;
            }
        }
    }
}
