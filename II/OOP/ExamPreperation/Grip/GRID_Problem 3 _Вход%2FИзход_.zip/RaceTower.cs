namespace GRID
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class RaceTower
    {
        private int currentLap;
        private int lapsNumber;
        private double trackLength;
        private Dictionary<string, Driver> drivers = new Dictionary<string, Driver>();
        private Dictionary<string, Driver> failedDrivers = new Dictionary<string, Driver>();
        public Driver winner { get; private set; }
        public void SetTrackInfo(int lapsNumber, int trackLength)
        {
            this.lapsNumber = lapsNumber;
            this.trackLength = trackLength;
            this.currentLap = 0;
        }

        public void RegisterDriver(List<string> commandArgs)
        {
            Driver driver;
            Car car;
            Tyre tyre;
            try
            {
                if (commandArgs[4] == "Ultrasoft")
                {
                    tyre = new UltrasoftTyre(double.Parse(commandArgs[5]), double.Parse(commandArgs[6]));
                }
                else
                {
                    tyre = new HardTyre(double.Parse(commandArgs[5]));
                }
                car = new Car(int.Parse(commandArgs[2]), double.Parse(commandArgs[3]), tyre);

                if (commandArgs[0] == "Aggressive")
                {
                    driver = new AggressiveDriver(commandArgs[1], car);
                }
                else driver = new EnduranceDriver(commandArgs[1], car);

                drivers.Add(commandArgs[1], driver);
            }
            catch
            {

            }
        }

        public void DriverBoxes(List<string> commandArgs)
        {
            if (commandArgs[0] == "ChangeTyres")
            {
                if (commandArgs[2] == "Ultrasoft")
                    drivers[commandArgs[1]].Car.ChangeTyre(new UltrasoftTyre(double.Parse(commandArgs[3]), double.Parse(commandArgs[4])));
                else
                    drivers[commandArgs[1]].Car.ChangeTyre(new HardTyre(double.Parse(commandArgs[3])));
            }
            else
            {
                drivers[commandArgs[1]].Car.AddFuel(double.Parse(commandArgs[2]));
            }

            drivers[commandArgs[1]].TotalTime += 20;
        }

        public string CompleteLaps(List<string> commandArgs)
        {
            if (int.Parse(commandArgs[0]) + currentLap <= lapsNumber)
            {
                currentLap += int.Parse(commandArgs[0]);
                for (int i = 0; i < int.Parse(commandArgs[0]); i++)
                {
                    foreach (var driver in drivers)
                    {
                        driver.Value.TotalTime += 60 / (trackLength / driver.Value.Speed);
                        try
                        {          
                            driver.Value.Car.FuelAmount -= trackLength * driver.Value.FuelConsumptionPerKm;
                            driver.Value.Car.Tyre.Degrade();
                        }
                        catch(ArgumentException ex)
                        {
                            if (!failedDrivers.ContainsKey(driver.Key))
                            {
                                failedDrivers.Add(driver.Key, driver.Value);
                                failedDrivers[driver.Key].DNF = ex.Message;
                            }
                        }
                    }
                }
                if (currentLap == lapsNumber)
                {
                    winner = drivers.Where(x=>x.Value.DNF==null).OrderBy(x => x.Value.TotalTime).First().Value;
                }
                return string.Empty;
            }
            else
                throw new ArgumentException($"There is no time! On lap {currentLap}.");

            
        }

        public string GetLeaderboard()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Lap {currentLap}/{lapsNumber}");
            int position = 1;
            foreach(var driver in drivers.Where(x=>x.Value.DNF ==null).OrderBy(x=>x.Value.TotalTime))
            {
                sb.AppendLine($"{position++} {driver.Key} {driver.Value.TotalTime :f3}");
            }
            foreach(var driver in failedDrivers.Reverse())
            {
                sb.AppendLine($"{position++} {driver.Key} {driver.Value.DNF}");
            }

            return sb.ToString().TrimEnd();
        }

    }
}