using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public class UltrasoftTyre : Tyre
    {

    public UltrasoftTyre(double hardness, double grip) : base("Ultrasoft", hardness, 30)
    {
        this.Grip = grip;
    }

    public double Grip { get; }
    }
}
