using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public abstract class Tyre
    {
        private const int DefaultDegradationMinimum = 0;

    private double degradation;
    private double degradationMinimum;

    protected Tyre(string name, double hardness, int degradationMin = DefaultDegradationMinimum)
    {
        this.Name = name;
        this.degradationMinimum = degradationMin;
        this.Hardness = hardness;
        this.Degradation = 100;
    }

    public string Name { get; }

    public double Hardness { get; }

    public double Degradation
    {
        get {return this.degradation;}
        protected set
        {
            if (value < this.degradationMinimum)
            {
                throw new ArgumentException("Blown Tyre");
            }

            this.degradation = value;
        }
    }

    public virtual void Degradate() => this.Degradation -= this.Hardness;
    }
}
