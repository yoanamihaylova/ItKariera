using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public class Car
    {

    private double fuelAmount;
    private int hp;

    public Car(int hp, double fuelAmount, Tyre tyreType)
    {
        this.hp = hp;
        this.Tyre = tyreType;
        this.FuelAmount = fuelAmount;
    }

    protected double FuelAmount
    {
        get => this.fuelAmount;
        private set
        {
            if(value>160)
             value=160;
            if (value < 0)
            {
                throw new ArgumentException(DriverFailiures.OutOfFuel);
            }
            fuelAmount = value;
        }
    }

    public Tyre Tyre { get; private set; }

    public double Speed => (this.hp + this.Tyre.Degradation) / this.FuelAmount;
    }
}
