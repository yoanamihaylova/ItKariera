using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public abstract class Driver
    {
    
    private double fuelConsumptionPerKm;

    protected Driver(string name, Car car, double fuelConsumption)
    {
        this.Name = name;
        this.Car = car;
        this.fuelConsumptionPerKm = fuelConsumption;
    }

    protected Car Car { get; }

    public string Name { get; }

    public double TotalTime { get; set; }

    public virtual double Speed => this.Car.Speed;
    }
}
