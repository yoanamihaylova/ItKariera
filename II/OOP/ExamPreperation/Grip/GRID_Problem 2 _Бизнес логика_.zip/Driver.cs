using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public abstract class Driver
    {
        public string Name { get; private set; }
        private double totalTime;
        public double TotalTime { get { return totalTime; } set { totalTime = value; } }
        public Car Car { get; private set; }
        
        public double FuelConsumptionPerKm { get; private set; }
        public string DNF;
        public double Speed => ((this.Car.Hp + this.Car.Tyre.Degradation) / this.Car.FuelAmount) * speedMultiplier;
        private double speedMultiplier;

        //TODO
        protected Driver(string name, Car car, double fuelConsumptionPerKm, double speedMultiplier)
        {
            this.Name = name;
            this.TotalTime = 0;
            this.Car = car;
            this.FuelConsumptionPerKm = fuelConsumptionPerKm;
            this.speedMultiplier = speedMultiplier;
            this.DNF = null;
        }
    }
}
