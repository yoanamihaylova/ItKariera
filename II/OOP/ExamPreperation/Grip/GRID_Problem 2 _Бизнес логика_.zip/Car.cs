using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRID
{
    public class Car
    {
        public int Hp { get; private set; }
        private double fuelAmount;
        public double FuelAmount
        {
            get { return fuelAmount; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Out of fuel"); //TODO
                fuelAmount = Math.Min(160, value);
            }
        }

        private Tyre tyre;
        public Tyre Tyre
        {
            get { return tyre; }
            set { tyre = value; }
        }

        public Car(int hp, double fuelAmount, Tyre tyre)
        {
            this.Hp = hp;
            this.FuelAmount = fuelAmount;
            this.Tyre = tyre;
        }

        public void AddFuel(double fuelAmount)
        {
            this.FuelAmount += fuelAmount;
        }

        public void ChangeTyre(Tyre tyre)
        {
            this.Tyre = tyre;
        }
    }
}
