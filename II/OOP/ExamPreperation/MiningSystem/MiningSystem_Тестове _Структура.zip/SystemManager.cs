using System;
using System.Collections.Generic;

namespace MiningSystem
{
    public class SystemManager
    {
        public string RegisterMiner(List<string> arguments)
        {
            throw new NotImplementedException();
        }

        public string RegisterProvider(List<string> arguments)
        {
            throw new NotImplementedException();
        }

        public string Day()
        {
            throw new NotImplementedException();
        }

        public string Check(List<string> arguments)
        {
            throw new NotImplementedException();
        }

        public string ShutDown()
        {
            throw new NotImplementedException();
        }
    }
}