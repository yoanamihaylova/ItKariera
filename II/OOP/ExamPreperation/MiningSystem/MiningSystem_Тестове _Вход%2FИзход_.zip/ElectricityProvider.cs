using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiningSystem
{
    public class ElectricityProvider : Provider
    {
        public ElectricityProvider(string id, double energyOutput) : base(id, energyOutput * 1.5)
        {
        }

        public override string ToString()
        {
            return "Electricity " + base.ToString();
        }
    }
}
