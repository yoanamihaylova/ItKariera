using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiningSystem
{
    public class Hewer : Miner
    {
        private int enduranceFactor;

        public Hewer(string id, double coalOutput, double energyRequirement, int enduranceFactor) : base(id, coalOutput, energyRequirement)
        {
            this.EnduranceFactor = enduranceFactor;
            this.EnergyRequirement = energyRequirement / enduranceFactor;
        }

        public int EnduranceFactor
        {
            get
            { return this.enduranceFactor; }
            protected set
            {
                if (value == 0)
                    throw new Exception($"Miner is not registered, because of it's {nameof(EnduranceFactor)}");
                this.enduranceFactor = value;
            }
        }

        public override string ToString()
        {
            return "Hewer " + base.ToString();
        }
    }
}
