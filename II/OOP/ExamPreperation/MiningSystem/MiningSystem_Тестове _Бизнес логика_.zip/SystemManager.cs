using System;
using System.Collections.Generic;
using System.Linq;

namespace MiningSystem
{
    public class SystemManager
    {
        private List<Miner> miners;
        private List<Provider> providers;
        private double totalStoredEnergy;
        private double totalMinedCoals;

        public SystemManager()
        {
            this.miners = new List<Miner>();
            this.providers = new List<Provider>();
        }

        public string RegisterMiner(List<string> arguments)
        {
            try
            {
                var type = arguments[0];
                var id = arguments[1];
                var coalOutput = double.Parse(arguments[2]);
                var energyRequire = double.Parse(arguments[3]);

                Miner miner;

                if (type == "Hewer")
                {
                    var enduranceFactor = int.Parse(arguments[4]);
                    miner = new Hewer(id, coalOutput, energyRequire, enduranceFactor);
                }
                else miner = new Driller(id, coalOutput, energyRequire);

                this.miners.Add(miner);

                return $"Successfully registered {type} Miner - {id}";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string RegisterProvider(List<string> arguments)
        {
            try
            {
                var type = arguments[0];
                var id = arguments[1];
                var energyOutput = double.Parse(arguments[2]);

                Provider provider;

                if (type == "Sun") provider = new SunProvider(id, energyOutput);
                else provider = new ElectricityProvider(id, energyOutput);

                this.providers.Add(provider);

                return $"Successfully registered {type} Provider - {id}";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string Day()
        {
            var energyProvided = this.providers.Sum(p => p.EnergyOutput);
            this.totalStoredEnergy += energyProvided;

            var neededEnergy = this.miners.Sum(m => m.EnergyRequirement);
            var minedCoals = 0.0;

            if (neededEnergy <= this.totalStoredEnergy)
            {
                minedCoals += this.miners.Sum(m => m.CoalOutput);
                this.totalStoredEnergy -= neededEnergy;
            }

            this.totalMinedCoals += minedCoals;

            return $"A day has passed.{Environment.NewLine}" +
                $"Energy Provided: {energyProvided}{Environment.NewLine}" +
                $"Mined Coal: {minedCoals}";
        }

        public string Check(List<string> arguments)
        {
            var id = arguments[0];

            if (this.miners.Any(m => m.Id == id)) return this.miners.First(m => m.Id == id).ToString();
            else if (this.providers.Any(p => p.Id == id)) return this.providers.First(p => p.Id == id).ToString();

            return $"No element found with id – {id}";
        }

        public string ShutDown()
        {
            return $"System Shutdown{Environment.NewLine}" +
                $"Total Energy Stored: {this.totalStoredEnergy}{Environment.NewLine}" +
                $"Total Mined Coal: {this.totalMinedCoals}";
        }
    }
}