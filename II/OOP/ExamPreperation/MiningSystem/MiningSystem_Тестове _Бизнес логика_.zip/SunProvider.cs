using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiningSystem
{
    public class SunProvider : Provider
    {
        public SunProvider(string id, double energyOutput) : base(id, energyOutput * 1.25)
        {

        }

        public override string ToString()
        {
            return "Sun " + base.ToString();
        }
    }
}
