using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiningSystem
{
    public abstract class Miner
    {
        private string id;
        private double coalOutput;
        private double energyRequirement;

        protected Miner(string id, double coalOutput, double energyRequirement)
        {
            this.Id = id;
            this.CoalOutput = coalOutput;
            this.EnergyRequirement = energyRequirement;
        }

        public string Id
        {
            get
            { return this.id; }
            protected set
            { this.id = value; }
        }

        public double CoalOutput
        {
            get
            { return this.coalOutput; }
            protected set
            {
                if (value < 0)
                    throw new Exception($"Miner is not registered, because of it's {nameof(CoalOutput)}");
                this.coalOutput = value;
            }
        }

        public double EnergyRequirement
        {
            get
            { return this.energyRequirement; }
            protected set
            {
                if (value < 0 || value > 20000)
                    throw new Exception($"Miner is not registered, because of it's {nameof(EnergyRequirement)}");
                this.energyRequirement = value;
            }
        }

        public override string ToString()
        {
            return $"Miner - {this.Id}{Environment.NewLine}" +
                $"Coal Output: {this.CoalOutput}{Environment.NewLine}" +
                $"Energy Requirement: {this.EnergyRequirement}";
        }
    }
}

