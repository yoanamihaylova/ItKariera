using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    class Car
    {
        private static int ordersCount=0;

        private string manufacturer;
                    
        public string Manufacturer
        {
            get { return manufacturer; }
            set
            {
                if (value.Length < 3)
                    throw new ArgumentException("Invalid manufacturer name!");
                manufacturer = value;
            }
        }

        private string model;

        public string Model
        {
            get { return model; }
            set
            {
                if (value.Length < 3)
                    throw new ArgumentException("Invalid model name!");
                model = value;
            }
        }

        private double loadCapacity;

        public double LoadCapacity
        {
            get { return loadCapacity; }
            set
            {
                if (value < 0)
                    throw new Exception("Invalid load capacity!");
                loadCapacity = value;
            }
        }

        private List<Part> parts = new List<Part>();
        public List<Part> Parts
        {
            get { return parts; }
            set { parts = value; }
        }
        private double fuel;

        public double Fuel
        {
            get { return fuel; }
            set { fuel = value; }
        }

        public Car(string manufacturer, string model, double loadCapacity)
        {
            Manufacturer = manufacturer;
            Model = model;
            LoadCapacity = loadCapacity;
            Fuel = 100;
            ordersCount++;
        }

        public double GetCarPrice()
        {
            double price = 0;
            foreach(var part in parts)
            {
                price += part.Price;
            }
            return price;
        }

        public override string ToString()
        {
            string result;
            result = $"{Model.ToUpper()} made by {Manufacturer}\n";
            result += "Available parts:\n";
            foreach(var part in parts)
            {
                result += $"{part.ToString()}\n";
            }
            result += $"With total price of: {GetCarPrice():f2} lv.";
            return result;
        }

        public void AddPart(Part part)
        {
            parts.Add(part);
        }
        public void AddMultipleParts(List<Part> passedParts)
        {
            foreach(var part in passedParts)
            {
                parts.Add(part);
            }
        }
        public void RemovePartByName(string name)
        {
            parts.Remove(parts.Where(x => x.Name == name).First());
        }

        public List<Part> GetPartsWithPriceAbove(double price)
        {
            List<Part> requestedParts = parts.Where(x => x.Price > price).ToList();
            return requestedParts;
        }
        public Part GetMostExpensivePart()
        {
            Part MostExpensive = parts.OrderByDescending(x => x.Price).First();
            return MostExpensive;
        }
        public static int OrdersCount
        {
            get { return ordersCount; }
        }
        public void Drive(double distance)
        {
            double expendedFuel= loadCapacity * 0.2 * distance;
            if (fuel<expendedFuel || distance<0)
                throw new ArgumentException("Drive not possible!");
            fuel -= expendedFuel;
        }
        public bool ContainsPart(string partName)
        {
            foreach(var part in parts)
            {
                if (part.Name == partName) return true;
            }
            return false;
        }
    }
}
