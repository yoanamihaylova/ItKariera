using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    public class Product
    {
        public string Type { get; }
        public string Name { get; }
        public double Price { get; }

        public static int OrdersCount { get; private set; }

        public Product(string type, string name, double price)
        {
            if (!string.Equals(type.ToUpper(), type)) throw new ArgumentException("Invalid type!");
            if (name.Length <= 2) throw new ArgumentException("Invalid name!");

            if (price <= 0) throw new ArgumentException("Invalid price!");
            Type = type;
            Name = name;
            Price = price;
        }

        public static void IncreaseOrdersCount() => ++OrdersCount;

        public override string ToString() => $"Product with type - {Type} and name - {Name}";

    }
}