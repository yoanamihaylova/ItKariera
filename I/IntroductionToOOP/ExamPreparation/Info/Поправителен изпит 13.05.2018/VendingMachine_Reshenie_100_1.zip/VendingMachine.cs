using System;
using System.Collections.Generic;
using System.Linq;

namespace Exam
{
    public class VendingMachine
    {
        private List<Product> _products;
        public string Id { get; }
        public double Battery { get; private set; } = 100d;
        public double TotalSalesAmount { get; private set; } = 0d;

        public VendingMachine(string id) : this(id, new List<Product>())
        {
        }
        public VendingMachine(string id, List<Product> products)
        {
            if (id.Length <= 3 || !string.Equals(id.ToLower(), id)) throw new ArgumentException("Invalid machine id!");
            _products = products;
            Id = id;
        }

        public void Recharge()
        {
            Battery = 100d;
        }

        public void ClearSales()
        {
            TotalSalesAmount = 0d;
        }

        public int CheckProductQuantityOfGivenType(string type) =>
            _products.Count(x => x.Type == type);


        public void AddProduct(Product product)
        {
            _products.Add(product);
        }


        public void RemoveProduct(string productName)
        {
            _products.Remove(GetProductByName(productName));
        }

        public Product GetMostExpensiveProduct()
        {
            return _products.OrderByDescending(x => x.Price).First();
        }

        public string SellProduct(string productName)
        {
            Product.IncreaseOrdersCount();
            var product = GetProductByName(productName);
            double batteryRequired = product.Price * 0.8d + 2d;

            if (Battery < batteryRequired) throw new ArgumentException("Out of battery!");

            Battery -= batteryRequired;
            TotalSalesAmount += product.Price;
            _products.Remove(product);

            return $"{product.Name} for {product.Price:F2}lv.";
        }

        public override string ToString() =>
            $@"Machine: {Id} has the following available products:
        {string.Join("\n", _products.Select(x => x.ToString()))}
        ---- With total sales amount: {TotalSalesAmount:F2}.";

        public void RemoveAllProductsOfGivenType(string type)
        {
            _products.Where(x => x.Type == type).ToList().ForEach(x => _products.Remove(x));
        }

        public string GetInfoAboutAllProductsByType() =>
            string.Join("\n", _products.GroupBy(x => x.Type).OrderBy(x => x.Sum(y => y.Price)).ThenBy(x => x.Key)
                .Select(t => $"Type: {t.Key} has total of - {t.Count()} products."));

        private Product GetProductByName(string name) => _products.SingleOrDefault(x => x.Name == name);



    }
}