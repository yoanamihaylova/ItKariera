using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Exam
{
	public class Company
	{
		private string name;
		private List<Employee> employees;
		private string city;

		public string Name
		{
			get
			{
				return name;
			}

			set
			{
				if (value.Length < 3)
				{
					throw new ArgumentException( "Invalid company name" );
				}
				name = value;
			}
		}

		public List<Employee> Employees
		{
			get
			{
				return employees;
			}

			set
			{
				employees = value;
			}
		}

		public string City
		{
			get
			{
				return city;
			}

			set
			{
				char[] chars = value.ToCharArray();
				string firstLetter = chars[0].ToString();
				if (value.Length < 4 || firstLetter == firstLetter.ToLower())
				{
					throw new ArgumentException( "Invalid city" );
				}
				city = value;
			}
		}

		public Company( string name, string city )
		{
			this.Name = name;
			this.City = city;
			this.employees = new List<Employee>();
		}

		public void HireEmployee( Employee emp )
		{
			Employees.Add( emp );
		}



		public void FireEmployee( string employeeId )
		{
			var emp = employees.Where( x => x.Id == employeeId ).ToArray();

			Employees.Remove( emp[0] );
		}



		public void IncreaseSalaries( double value )
		{
			foreach (var employee in Employees)
			{
				employee.Salary += value;
			}

		}



		public void DecreaseSalaries( double value )
		{
			foreach (var emp in Employees)
			{
				if (emp.Salary>=value)
				{
					emp.Salary -= value;
				}
			}
		}



		public Employee GetMostHighPaidEmployee()
		{
			var emp = new Employee();
			foreach (var employee in Employees)
			{
				if (employee.Salary>emp.Salary)
				{
					emp = employee;
				}
			}
			return emp;

		}

		public List<Employee> GetTopThreeMostHighPaidEmployees()
		{
			var list = Employees.OrderByDescending(x => x.Salary);
			return list.Take( 3 ).ToList();

		}



		public bool CheckEmployeeIsPresent( string employeeId )
		{
			var flag = false;
			foreach (var emp in Employees)
			{
				if (emp.Id==employeeId)
				{
					flag = true;
				}
			}
			return flag;

		}



		public double GetAverageEmployeeSalary()
		{
			return Employees.Average( x => x.Salary );

		}

 
		public override string ToString()
		{
			var sb = new StringBuilder();
			sb.Append( $"Company {Name} from {City} has the following employees:\n" );
			foreach (var employee in employees)
			{
				sb.Append( $"-->Employee: {employee.FirstName} {employee.LastName} with id: {employee.Id} and salary: {employee.Salary:f2}\n" );
			}

			return sb.ToString();
		}
	}
}
