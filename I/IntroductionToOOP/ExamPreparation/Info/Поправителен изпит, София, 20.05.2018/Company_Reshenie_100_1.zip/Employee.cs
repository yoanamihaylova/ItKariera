using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Employee
    {
        private string firstName;
        private string lastName;
        private double salary;
        private int age;
        private string id;

        public Employee(string id, string firstName, string lastName, int age)

        {
            if (firstName.Length <= 2 || firstName.Length > 8)
            {
                throw new ArgumentException("Invalid employee name");
            }
            if (lastName.Length <= 2 || lastName.Length > 8)
            {
                throw new ArgumentException("Invalid employee name");
            }
            
            if (age < 0)
            {
                throw new ArgumentException("Invalid employee age");
            }

            salary = 500;
            this.lastName = lastName;
            this.firstName = firstName;
            this.age = age;
            this.id = id;

        }

        public Employee(string id, string firstName, string lastName, int age, double salary)

        {
            if ((firstName.Length <= 2 || firstName.Length > 8) && (lastName.Length <= 2 || lastName.Length > 8))
            {
                throw new ArgumentException("Invalid employee name");
            }
            if (age < 0)
            {
                throw new ArgumentException("Invalid employee age");
            }

            this.lastName = lastName;
            this.firstName = firstName;
            this.age = age;
            this.id = id;
            this.salary = salary;

        }
        public string LastName
        {
            get { return lastName; }
        }
        public string FirstName
        {
            get { return firstName; }
        }

        public string Id
        {
            get { return id; }
        }

        public double Salary
        {
            get { return salary; }
        }

        public int Age
        {
            get { return age; }
        }
        public void SalaryIncrease(double value)
        {
            salary += value;
        }
        public void SalaryDecrease(double value)
        {
            salary -= value;
        }

        public override string ToString()

        {
            return $"Employee: {this.firstName} {this.lastName} with id: {this.id} and salary: {this.salary:f2}";
        }
    }
}
