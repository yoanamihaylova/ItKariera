using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Company
    {
        private string name;
        private List<Employee> employees;
        private string city;

        public Company(string name, string city)

        {
            if (name.Length <= 2)
            {
                throw new ArgumentException("Invalid company name");
            }
            if (city.Length < 4 || char.IsLower(city[0]))
            {
                throw new ArgumentException("Invalid city");
            }
            this.name = name;
            this.city = city;
            employees = new List<Employee>();
        }

        public string Name
        {
            get { return name; }
        }

        public string City
        {
            get { return city; }
        }

        public void HireEmployee(Employee emp)

        {
            employees.Add(emp);
        }

        public void FireEmployee(string id)

        {
            employees = employees.Where(x => x.Id != id).ToList();
        }

       public void IncreaseSalaries(double value)

        {
            for (int i = 0; i < employees.Count; i++)
            {
                employees[i].SalaryIncrease(value);
            }
        }

        public void DecreaseSalaries(double value)

        {
            for (int i = 0; i < employees.Count; i++)
            {
                employees[i].SalaryDecrease(value);
            }
        }

        public Employee GetMostHighPaidEmployee()

        {
            return employees.OrderByDescending(x => x.Salary).First();
        }

        public List<Employee> GetTopThreeMostHighPaidEmployees()
        {
                 return employees.OrderByDescending(x => x.Salary).Take(3).ToList();
        }
        public bool CheckEmployeeIsPresent(string id)

        {
            if (employees.Where(x => x.Id == id).Count() == 1)
            {
                return true;
            }
            return false;
        }

        public double GetAverageEmployeeSalary()

        {
            return employees.Sum(x => x.Salary) / employees.Count();
        }

        public override string ToString()

        {

            string message = $"Company {name} from {city} has the following employees:\n";
            foreach (var employeeInfo in employees)
            {
                message += "--->" + employeeInfo + "\n";
            }
            return message;
        }
    }
}